
   
Make sure to copy template-x.x.x.jar to  package\template.jar 

See build.xml 
    target name="JavaPackager"
    