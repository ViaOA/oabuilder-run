

Make sure that template.jar and lib\oa-*.jar are the latest releases.

See build.xml 
    target name="JavaPackager"

    
    