

See project OAAppStore-Installer for creating a small installer.
