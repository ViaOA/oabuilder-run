oatemplate
==========

Template project used by OABuilder to generate a new project.
