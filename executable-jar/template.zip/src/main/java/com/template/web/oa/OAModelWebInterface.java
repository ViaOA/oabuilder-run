package com.template.web.oa;

import com.viaoa.hub.Hub;
import com.viaoa.object.OAObjectModel;

public interface OAModelWebInterface {

    public Hub<?> getHub();
    
    public OAObjectModel getModel();
    
    

}
