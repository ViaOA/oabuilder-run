package com.template.delegate;

import java.util.logging.Logger;

import com.template.model.oa.*;
import com.template.jsp.oa.*;
import com.viaoa.hub.*;
import com.viaoa.jsp.*;
import com.viaoa.util.*;

public class JspDelegate {
	private static Logger LOG = Logger.getLogger(JspDelegate.class.getName());

	public static final String JSP_DemoJsp = "demoJsp";
	
	
	public static void set(OASession sess) {
	}

	
	
	
}
