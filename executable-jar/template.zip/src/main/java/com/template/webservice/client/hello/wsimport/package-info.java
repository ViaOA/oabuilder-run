// Copied from OATemplate project by OABuilder 07/01/16 07:41 AM
@javax.xml.bind.annotation.XmlSchema(namespace = "http://server.webservice.templaze.com/")
package com.template.webservice.client.hello.wsimport;
